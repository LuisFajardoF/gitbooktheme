# Generaci'on de tablas con el entorno tabular

![Tabla 1]{
    column 1|column 2 |column 3
    :-------|:--------|:------:
    abc     | def     | ghi    
    123     | 456     | 789    
    987     | 654     | 321    
    9.87    | 6.54    | 3.21    
    68.7    | 65.4    | 32.1    
    jkl     | mno     | pqr
            | xyz     | abc    
}

![Tabla con unidades alineadas.;style1-green]{
    Value 1 |Value 2  |Value 3| Value 4
    :-------|<------->|------:|:-------:
    1       | 1110.10 | a     | 0.1
    2       | 10.10   | b     | 0.01
    3       | 23.11   | c     | 0.001
    4       | 233.18  | d     | 0.0001
    5       | 963.36  | e     | 0.00001
    6       | 113.36  | f     | 0.000001
}

![Tabla con unidades alineadas en dos columnas.;style1]{
    Value 1 |Value 2  |Value 3
    :-------|<------->|<------>
    1       | 1110.10 | 0.00001
    2       | 10.10   | 0.9090
    3       | 23.11   | 0.8900
}

---

![Tabla con unidades alineadas en dos columnas.; style2-olive]{
    Value 1 |Value 2  |Value 3
    :-------|<------->|<------>
    1       | 1110.10 | 0.00001
    2       | 10.10   | 0.9090
    3       | 23.11   | 0.8900
}