!--
    lot: yes
--!

![Tabla con unidades alineadas en dos columnas.;style1]{
    Value 1 |Value 2  |Value 3
    :-------|<------->|<------>
    1       | 1110.10 | 0.00001
    2       | 10.10   | 0.9090
    3       | 23.11   | 0.8900
}

![Valores aleatorios para la Tabla 1.; style1; csv]{
        ../csv/table1.csv
}

![Valores aleatorios para la Tabla 2.; style1-lime; csv]{
        ../csv/table2.csv
}
