!--
    bibstyle: apa
--!

This is a bibliography test [1].  
This is a bibliography test [2].  
This is a bibliography test [3].

```bib
[1]: article {
    author:     Albert Einstein
    title:      Zur Elektrodynamik bewegter Korper
    journal:    Annalen der Physik
    volume:     322
    number:     10
    pages:      891--921
    year:       1905
    doi:        http://dx.doi.org/10.1002/andp.19053221004       
}

[2]: book {
    author:     Michel Goossens and Frank Mittelbach and Alexander Samarin
    title:      The LaTeX Companion
    year:       1993
    publisher:  Addison-Wesley
    address:    Reading, Massachusetts
}

[3]: misc {
    author:     Donald Knuth
    title:      Knuth: Computers and Typesetting
    url:        http://www-cs-faculty.stanford.edu/uno/abcde.html
    note:       accessed on 2021-02-16
}
```
