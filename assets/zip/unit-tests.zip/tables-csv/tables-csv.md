# Generaci'on de tablas con el paquete pgfplotstable

![Valores de Tabla 1.;csv]{
        ../csv/table1.csv
}

![Valores de Tabla 2.;style1;csv]{
        ../csv/table2.csv
}

![Valores de Tabla 3.;style1-blue; csv]{
        ../csv/table1.csv
}

![Valores de Tabla 4.;style2; csv]{
        ../csv/table3.csv
}

---

![Valores de Tabla 5.;style2-green; csv]{
        ../csv/table3.csv
}