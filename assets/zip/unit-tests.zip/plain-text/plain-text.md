!--
    cover: default {
        title: El inspector Cambalache y el robo en el museo
        author: Eva Mar'ia Rodr'iguez
    }
--!

Oy'o la conversaci'on y no pod'ia creer lo que pasaba. Tras las cortinas, el inspector 
Cambalache permanec'ia escondido mientras aquellas dos personas tan siniestras planeaban 
el robo de los cuadros m'as valiosos del museo de la ciudad. El pobre inspector estaba 
muerto de miedo, y no sab'ia qu'e hacer. As'i que esper'o a que los ladrones se marcharan 
para salir de su escondite y avisar a sus compa~neros de la comisar'ia para que evitaran 
el robo. Pensar'eis que el inspector Cambalache era un poco cobarde. La verdad es que s'i, 
pero 'el se defend'ia diciendo que era una persona prudente y que pensaba bien las cosas 
antes de actuar.