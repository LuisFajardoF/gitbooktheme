!--
    cover: report {
        logo: logo_unitec.jpg
        institution: Universidad Tecnol'ogica Centroamericana
        title: Herencia y Polimorfismo
        subject: Lenguajes de Programaci'on
        author: 1st Author & 2nd Author
        date: today
        place: San Pedro Sula, Honduras
    }
--!
