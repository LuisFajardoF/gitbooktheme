!--
    lof: yes
--!

## Ciudades Coloniales

![Ciudad de Cartagena de Indias, w=8cm, h=6cm, oht](cartagena_indias.jpg)
![Ciudad de San Miguel Allende, w=8cm, h=6cm, oht](san_miguel_allende.jpg)
![Ciudad de Cuzco, w=10cm, h=7cm, oht](cuzco.jpg)

## Figuras Planas

![{Figuras geometricas de dos dimensiones, oht}:Cuadrado, w=2.5cm, h=2.5cm; Circulo, w=2.5cm, h=2.5cm; Rombo, s=0.5; Pentagono, s=0.5, a=45](figuras2d/cuadrado.png, figuras2d/circulo.png, figuras2d/rombo.png, figuras2d/pentagono.png) 
