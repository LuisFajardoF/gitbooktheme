!--
    pagenumbering: gobble
--!

## Esta p'agina no est'a numerada.

---

!--
    pagenumbering: Roman
--!

## A partir de esta p'agina se numera con: _Roman_ y la numeraci'on comenzar'a en I. 

---

!--
    pagenumbering: Alph
--!

## A partir de esta p'agina se numera con: _Alph_ y la numeraci'on comenzar'a en A.

---

!--
    pagenumbering: arabic {
        set: 6
    }
--!

## A partir de esta p'agina se numera con: _arabic_ y la numeraci'on comenzar'a en 6.
